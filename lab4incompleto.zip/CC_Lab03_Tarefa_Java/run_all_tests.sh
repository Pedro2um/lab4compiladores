#!/bin/bash

# Define o diretório onde os arquivos estão localizados
DIR="/home/pigmorais/CC_Lab03_Tarefa_Java/in"
# Percorre todos os arquivos no diretório
for FILE in "$DIR"/*; do
    # Executa o comando make run para cada arquivo
    make run FILE="$FILE" > $FILE.txt
done